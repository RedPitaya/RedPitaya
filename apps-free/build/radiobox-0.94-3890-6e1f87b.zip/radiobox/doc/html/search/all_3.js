var searchData=
[
  ['calibration_20data',['Calibration data',['../group__calib__h.html',1,'']]],
  ['cast_5f1xdouble_5fto_5f4xbf',['cast_1xdouble_to_4xbf',['../group__main__h.html#ga102ab7df4493de65d1244eeb75baf314',1,'cast_1xdouble_to_4xbf(float *f_se, float *f_hi, float *f_mi, float *f_lo, double d):&#160;main.c'],['../group__main__h.html#ga102ab7df4493de65d1244eeb75baf314',1,'cast_1xdouble_to_4xbf(float *f_se, float *f_hi, float *f_mi, float *f_lo, double d):&#160;main.c']]],
  ['cast_5f4xbf_5fto_5f1xdouble',['cast_4xbf_to_1xdouble',['../group__main__h.html#gaf8f670a8811dbc8567bec8e148d7e4a8',1,'cast_4xbf_to_1xdouble(float f_se, float f_hi, float f_mi, float f_lo):&#160;main.c'],['../group__main__h.html#gaf8f670a8811dbc8567bec8e148d7e4a8',1,'cast_4xbf_to_1xdouble(float f_se, float f_hi, float f_mi, float f_lo):&#160;main.c']]],
  ['callback_20functions_20of_20the_20http_20get_2fpost_20parameter_20transfer_20system',['CallBack functions of the HTTP GET/POST parameter transfer system',['../group__cb__http__h.html',1,'']]],
  ['callback_20functions_20of_20the_20websocket_20parameter_20transfer_20system',['CallBack functions of the WebSocket parameter transfer system',['../group__cb__ws__h.html',1,'']]],
  ['conf_5f1',['conf_1',['../structfpga__sys__xadc__reg__mem__s.html#ae278f62628b9c88fb71798a7ca782e3b',1,'fpga_sys_xadc_reg_mem_s']]],
  ['conf_5f2',['conf_2',['../structfpga__sys__xadc__reg__mem__s.html#ad57464746284ea7827389304fbd12e7f',1,'fpga_sys_xadc_reg_mem_s']]],
  ['conf_5f3',['conf_3',['../structfpga__sys__xadc__reg__mem__s.html#ac8d1caf489b4d434b3c7bce7d6b3d84d',1,'fpga_sys_xadc_reg_mem_s']]],
  ['convstr',['convstr',['../structfpga__sys__xadc__reg__mem__s.html#a0291e00fdc50626de3021cd315609316',1,'fpga_sys_xadc_reg_mem_s']]],
  ['ctrl',['ctrl',['../structfpga__rb__reg__mem__s.html#a8ffb4e57f6fecdf455530bee54b11bde',1,'fpga_rb_reg_mem_s']]]
];
