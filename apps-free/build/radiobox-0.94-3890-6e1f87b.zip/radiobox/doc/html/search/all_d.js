var searchData=
[
  ['osc1_5finc_5fhi',['osc1_inc_hi',['../structfpga__rb__reg__mem__s.html#a37df4c99865091aa25443bfa4972900d',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5finc_5flo',['osc1_inc_lo',['../structfpga__rb__reg__mem__s.html#ae464bf5f41ce3d41a89f7d7cb708a9fe',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5fmix_5fgain',['osc1_mix_gain',['../structfpga__rb__reg__mem__s.html#a8d2f2e2504575b8f9354f96f300a3e8a',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5fmix_5fofs_5fhi',['osc1_mix_ofs_hi',['../structfpga__rb__reg__mem__s.html#a1671daf6187e35d4a39b74a41e0290e1',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5fmix_5fofs_5flo',['osc1_mix_ofs_lo',['../structfpga__rb__reg__mem__s.html#aa1c938ede8d70dafe5ea433d68a9983b',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5fofs_5fhi',['osc1_ofs_hi',['../structfpga__rb__reg__mem__s.html#af2fa408533d469637c8ee3f0c045f39d',1,'fpga_rb_reg_mem_s']]],
  ['osc1_5fofs_5flo',['osc1_ofs_lo',['../structfpga__rb__reg__mem__s.html#a699018b83a40eb970f902e7d9be86383',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5finc_5fhi',['osc2_inc_hi',['../structfpga__rb__reg__mem__s.html#aa92d65e09fe7e9f4a9d2d6185f9d1b4c',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5finc_5flo',['osc2_inc_lo',['../structfpga__rb__reg__mem__s.html#aac2d2868883b42b4a4e1d9b8fd67dca8',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5fmix_5fgain',['osc2_mix_gain',['../structfpga__rb__reg__mem__s.html#aea53c55031c766ac0da2f71cfa6c5605',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5fmix_5fofs_5fhi',['osc2_mix_ofs_hi',['../structfpga__rb__reg__mem__s.html#a62e5ccf4c094d0811d1a9199726cd67e',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5fmix_5fofs_5flo',['osc2_mix_ofs_lo',['../structfpga__rb__reg__mem__s.html#a2f84082514cf9e876afa9f8bc8997abc',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5fofs_5fhi',['osc2_ofs_hi',['../structfpga__rb__reg__mem__s.html#a487e8d532a709ae03c8951961b9a27a5',1,'fpga_rb_reg_mem_s']]],
  ['osc2_5fofs_5flo',['osc2_ofs_lo',['../structfpga__rb__reg__mem__s.html#ab33c786b1b7bfc87f8df77e802f88463',1,'fpga_rb_reg_mem_s']]]
];
