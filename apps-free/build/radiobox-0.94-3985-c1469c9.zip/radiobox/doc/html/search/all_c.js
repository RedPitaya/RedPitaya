var searchData=
[
  ['name',['name',['../structrp__app__params__s.html#a6c8de1762ad7a0812fc1e1f75c2d510b',1,'rp_app_params_s::name()'],['../structrb__app__params__s.html#a78a124140c7b729cc57d530017aca0b4',1,'rb_app_params_s::name()']]]
];
