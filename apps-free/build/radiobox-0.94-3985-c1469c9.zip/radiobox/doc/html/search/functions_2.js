var searchData=
[
  ['is_5fquad',['is_quad',['../group__main__h.html#gae1887ab50812cffc26d28063a24abbd0',1,'is_quad(const char *name):&#160;main.c'],['../group__main__h.html#gae1887ab50812cffc26d28063a24abbd0',1,'is_quad(const char *name):&#160;main.c']]]
];
