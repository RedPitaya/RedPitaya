var searchData=
[
  ['trace_5flength',['TRACE_LENGTH',['../group__main__h.html#gae1e334abc619db5fcf41b2092a41b174',1,'main.h']]],
  ['trace_5fnum',['TRACE_NUM',['../group__main__h.html#gac8d26e3c4da9e8683299e1350fb73fbd',1,'main.h']]]
];
