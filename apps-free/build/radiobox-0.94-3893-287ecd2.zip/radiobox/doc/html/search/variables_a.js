var searchData=
[
  ['led_5fctrl',['led_ctrl',['../structfpga__rb__reg__mem__s.html#af60428fb26c197d12f2c8edc2956dfc3',1,'fpga_rb_reg_mem_s']]],
  ['leds',['leds',['../structfpga__hk__reg__mem__s.html#a25c7e56f99bd3402ebad62ad2bdc272b',1,'fpga_hk_reg_mem_s']]]
];
