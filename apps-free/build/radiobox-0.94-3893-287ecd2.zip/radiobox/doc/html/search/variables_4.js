var searchData=
[
  ['digital_5floop',['digital_loop',['../structfpga__hk__reg__mem__s.html#ac3b4257afa8558b11ee5023646a53d41',1,'fpga_hk_reg_mem_s']]],
  ['dma_5fctrl',['dma_ctrl',['../structfpga__rb__reg__mem__s.html#a7d9ca8e3c75419bd2e0cc735ad4d39b1',1,'fpga_rb_reg_mem_s']]],
  ['dna_5fhi',['dna_hi',['../structfpga__hk__reg__mem__s.html#a0f79b67a665d3ca0b60acf65c62c9798',1,'fpga_hk_reg_mem_s']]],
  ['dna_5flo',['dna_lo',['../structfpga__hk__reg__mem__s.html#a3c495b98ddeb348ac7c0bc789593a3e6',1,'fpga_hk_reg_mem_s']]]
];
