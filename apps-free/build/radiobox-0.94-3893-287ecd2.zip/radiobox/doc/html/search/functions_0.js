var searchData=
[
  ['cast_5f1xdouble_5fto_5f4xbf',['cast_1xdouble_to_4xbf',['../group__main__h.html#ga102ab7df4493de65d1244eeb75baf314',1,'cast_1xdouble_to_4xbf(float *f_se, float *f_hi, float *f_mi, float *f_lo, double d):&#160;main.c'],['../group__main__h.html#ga102ab7df4493de65d1244eeb75baf314',1,'cast_1xdouble_to_4xbf(float *f_se, float *f_hi, float *f_mi, float *f_lo, double d):&#160;main.c']]],
  ['cast_5f4xbf_5fto_5f1xdouble',['cast_4xbf_to_1xdouble',['../group__main__h.html#gaf8f670a8811dbc8567bec8e148d7e4a8',1,'cast_4xbf_to_1xdouble(float f_se, float f_hi, float f_mi, float f_lo):&#160;main.c'],['../group__main__h.html#gaf8f670a8811dbc8567bec8e148d7e4a8',1,'cast_4xbf_to_1xdouble(float f_se, float f_hi, float f_mi, float f_lo):&#160;main.c']]]
];
