#!/bin/sh

echo heartbeat > /sys/class/leds/led9/trigger
